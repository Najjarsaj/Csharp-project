﻿using System.IO;
namespace FinalProject
{
    // this class just for reading the csv file just for the first time and when the has been passed this class 
    // the file will not be reading from this class 
    class FileHandler
    {
        public static readonly string PercentageFilePaths = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Paths.txt");
        private string? coursePercentageFileName;
        private string? name;
        private string? lastName;
        private string? id;
        private int year;
        private List<int>? tasks;
        private readonly List<Student> students;
        private readonly string? path;
        private readonly string filename;
        private readonly JsonHandler jsonHandler;
        public FileHandler(string? path,string filename)
        {
            this.path = path;
            students = new List<Student>();
            jsonHandler = new JsonHandler();
            DateTime currentDate = DateTime.Now;
            // file name is like filename_date
            this.filename = filename + currentDate.ToString("yyyy-MM-dd-HH-mm");
        }
        // this func to extract data from a specific csv file 
        public string ExtractData()
        {
            int counter = 0;
            // read data from the file
            using (StreamReader reader = new StreamReader(path!))
            {
                while (reader.EndOfStream == false)
                {
                    // the data in csv file is separated by , 
                    List<string?> tokens = reader.ReadLine()!.Split(',').ToList()!;
                    // the first line in the csv file is the heading for every column
                    if (counter==0)
                    {
                        // this is the name of the file that we will be fill into it the exam name and the Percentage for every exam
                        coursePercentageFileName =  Path.Combine(AppDomain.CurrentDomain.BaseDirectory,$"Course_Percentage{filename}.txt");
                        using (StreamWriter writer = new StreamWriter(coursePercentageFileName))
                        {
                            // here is for write to coursePercentageFileName the exam name and the Percentage for every exam
                            foreach (string? token in tokens)
                            {
                                if (token!.Contains('-'))
                                {
                                    string[] parts = token.Split('-');
                                    string trim = parts[0].Trim();
                                    string percentageString = parts[1].Trim().Replace("%", "");
                                    writer.WriteLine($"{trim}-{percentageString}");
                                }
                            }
                            writer.Close();
                        }
                        counter++;
                    }
                    else
                    {
                        // here we enter if we are not on the first line
                        // every line not the first line is an data line
                        FillFields(tokens);
                    }
                }
            }
            // add the name of the exam file Percentage name to file to be able to read in further time
            PercentFileWriter();
            string x = Path.Combine(AppDomain.CurrentDomain.BaseDirectory,filename+".json");
            // write the data to json to be able to edit it and do something with it because we cant edit the csv file
            jsonHandler.WriteToJson(x,students,filename);
            return filename;
        }
        // here to read the data lines and to fill it in the student and then write it to json files
        private void FillFields(List<string?> tokens) 
        {
            // the tokens in shape of 
            // name,lastname,id,year,task,task,task
            // every task is an int value 
            // the tokens is an line has been parsed 
            tasks = new List<int>(); 
            foreach (string? token in tokens)
            {
                // the first column is the first name
                if (token == tokens[0])
                {
                    name = token;
                }
                // the second column is last name
                else if (token == tokens[1])
                {
                    lastName = token;
                }
                // and then id 
                else if (token == tokens[2])
                {
                    id = token;
                }
                // and then study year
                else if (token==tokens[3])
                { 
                    int.TryParse(token , out year);
                }
                // at least the task from one task up tp 30 task 1..30
                else
                {
                    // tasks is an List<int>
                    tasks.Add(int.Parse(token!));
                }   
            }
            // fill the student with the extracted data
            Student student = new Student(name, lastName, id, year, tasks);
            // add the student to students array to write it to the json file when we finish reading all the csv file
            students.Add(student);
        }

        private void PercentFileWriter()
        {
            using StreamWriter writer = new StreamWriter(PercentageFilePaths,true);
            writer.WriteLine(coursePercentageFileName);
        }
        
    }
}
