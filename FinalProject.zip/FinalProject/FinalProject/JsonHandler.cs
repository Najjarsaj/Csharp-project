﻿using System.IO;
using Newtonsoft.Json;

namespace FinalProject;

public class JsonHandler
{
    private readonly string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
    private readonly string jsonFilesPath;
    private readonly string jsonNamesPath;

    public JsonHandler()
    {
        // there is a files in the baseDirectory to read from it the name of the file and where is the file from jsonFiles
        jsonFilesPath = Path.Combine(baseDirectory, "JsonFiles.txt");
        jsonNamesPath = Path.Combine(baseDirectory, "JsonNames.txt");
        EnsureFileExists(jsonFilesPath);
        EnsureFileExists(jsonNamesPath);
    }
    // to check if the path exists
    private void EnsureFileExists(string path)
    {
        if (!File.Exists(path))
        {
            File.Create(path).Dispose();
        }
    }   
    // this func to write to json 
    // is has been used from the file handler when finish extract data from the file we write to json to be used from now on 
    public void  WriteToJson(string outputPath, List<Student> students, string fileName)
    { 
        // students is the data  
        string json = JsonConvert.SerializeObject(students, Formatting.Indented);
        File.WriteAllText(outputPath, json);
        // the path for the file
        AppendToFile(jsonFilesPath, outputPath);
        // the name of the file to be opened
        AppendToFile(jsonNamesPath, fileName);
    }
    // this func to write to file
    private void AppendToFile(string filePath, string content)
    {
        using StreamWriter writer = new StreamWriter(filePath, true);
        writer.WriteLine(content);
    }
    
    public List<string> ReadJsonNames()
    {
        return ReadLinesFromFile(jsonNamesPath);
    }

    private List<string> ReadLinesFromFile(string filePath)
    {
        var lines = new List<string>();
        using StreamReader reader = new StreamReader(filePath);
        while (reader.ReadLine()! is { } line)
        {
            lines.Add(line);
        }

        return lines;
    }
    // this func receive an file name and read the file name and return the data as list<student>
    public List<Student?> FindReadName(string? name)
    {
        string jsonFilePath = FindJsonFilePath(name!);
        if (string.IsNullOrEmpty(jsonFilePath) || !File.Exists(jsonFilePath))
            return new List<Student?>();

        string jsonData = File.ReadAllText(jsonFilePath);
        return JsonConvert.DeserializeObject<List<Student>>(jsonData)!;
    }   
    // this func is receiving the file name and search in the json files file were the path for this file name that has been given 
    private string FindJsonFilePath(string name)
    {
        var lines = ReadLinesFromFile(jsonFilesPath);
        foreach (var line in lines)
        {
            if (line.EndsWith(name + ".json"))
                return line;
        }
        return "";
    }
    // this file is for updating the json file after click on the save button
    public bool UpdateJson(string fileName, Student updatedStudent)
    {
        // to get all the old data from the file
        List<Student> students = FindReadName(fileName)!;
        if (students.Count == 0)
            return false;
        // this is for finding the student with the given id in the array and return the index in the array 
        int index = students.FindIndex(s => s?.Id == updatedStudent.Id);
        if (index == -1)
            return false;
        // replace the old student with the new one    
        students[index] = updatedStudent;
        // write all the new data back to the json file
        string json = JsonConvert.SerializeObject(students, Formatting.Indented);
        string jsonFilePath = FindJsonFilePath(fileName);
        if (string.IsNullOrEmpty(jsonFilePath))
            return false;

        File.WriteAllText(jsonFilePath, json);
        return true;
    }
    // this func is for extracting the  Percentage and the courser name  of every course from the Percentage file and course names files 
    public void ExtractCoursesPercentage(List<string> courses, List<int> percentages,string fileName)
    {
        courses.Clear();
        percentages.Clear();
        string name = "";
        // PercentageFilePaths is the Percentage file to read the courses Percentages from
        using (StreamReader reader = new StreamReader(FileHandler.PercentageFilePaths))
        {
            // to set the poinnteer back to the top of the file
            reader.BaseStream.Seek(0, SeekOrigin.Begin);
            while (reader.EndOfStream == false)
            {
                // here we found with file path the the data is in
                string line = reader.ReadLine()!;
                if (line.Contains(fileName))
                {
                    name = line;
                    break;
                }
            }
            reader.Close();
        }

        if (name.Length != 0)
        {
            // here we read the file data that we find above
            using StreamReader reader = new StreamReader(name);
            while (reader.EndOfStream == false)
            {
                // the data in the file is like C#-60
                //C# is the course name and the 60 is the Percentage 
                List<String> tokens = reader.ReadLine()!.Split("-").ToList();
                courses.Add(tokens[0]);
                percentages.Add(int.Parse(tokens[1]));
                // this func to extract the following data to be able to calc the overall average for the course
            }
        }
    }
    
}
