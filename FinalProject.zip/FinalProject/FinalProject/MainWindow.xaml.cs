﻿using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using Path = System.IO.Path;

namespace FinalProject
{
    public partial class MainWindow
    {
        private string? path;
        private string? pathWithoutExtension;
        private FileHandler handler;
        private readonly JsonHandler jsonHandler;
        private  string? fileName;
        private readonly List<string> coursesNames;
        private readonly List<int> percentages;

        public MainWindow()
        {
            InitializeComponent();
            // this the listbox to the student detail spot i wanted to be hidden in the first
            StudentDetails.Visibility = Visibility.Hidden;
            // handler is an object to the class file handler 
            handler = new FileHandler("","");
            // json handler for handle read and write to json file
            jsonHandler = new JsonHandler();
            // some arrays to be used later
            coursesNames = new List<string>();
            percentages = new List<int>();
            FillComboBox();
        }
        // this func to handle the load button event
        private void Button_func(object sender, RoutedEventArgs e)
        {
            Button button = (sender as Button)!;
            switch (button.Name)
            {
                // if the button that been clicked is the load button 
                case "LoadButton":
                    // open the window to chose files from it
                    OpenFileDialog fileDialog = new OpenFileDialog
                    {
                        // apply filter to window to just look for csv files
                        Filter = "Excel Files | *.csv"
                    };
                    bool? success = fileDialog.ShowDialog();
                    if (success == true)
                    {
                        ListBox.Items.Clear();
                        // this the path 
                        path = fileDialog.FileName;
                        PathBreakDown();
                        if (pathWithoutExtension != null) CourseNameText.Text = pathWithoutExtension;
                        if (fileName != null) handler = new FileHandler(path, fileName);
                        fileName = handler.ExtractData();
                        ListBoxFill();
                    }
                    break;
            }
        }
        // this func to fill the ListBox the listBox is the place where to find all the students sorted by name
        private void ListBoxFill()
        {
            // this line to read from the json file the data and return it in student form 
            List<Student?> students = jsonHandler.FindReadName(fileName);
            // to sort according to name
            ListBox.DisplayMemberPath = "Name";
            foreach (Student? student in students) ListBox.Items.Add(student);
            if (fileName != null) jsonHandler.ExtractCoursesPercentage(coursesNames, percentages, fileName);
            // this func for calculating the overall average to the class
            Grade();
        }

        // this is func to handle the item clicked in the listbox
        private void ItemClicked(object sender, RoutedEventArgs e)
        {
            if (ListBox.SelectedItem != null)
            {
                // the item in the list box is a student 
                Student? selectedStudent = ListBox.SelectedItem as Student;
                StudentInfo.Items.Clear();
                if (selectedStudent != null)
                {
                    // here we add to the student info list box the following details
                    StudentInfo.Items.Add("Name: " + selectedStudent.Name);
                    StudentInfo.Items.Add("LastName: " + selectedStudent.LastName);
                    StudentInfo.Items.Add("id: " + selectedStudent.Id);
                    StudentInfo.Items.Add("Year: " + selectedStudent.Year);
                    FillStudentDetail(selectedStudent);
                }
            }
            // if we click the comboBox
            if (ComboBox.SelectedItem != null)
            {
                ListBox.Items.Clear();
                fileName = ComboBox.SelectedItem as string;
                // to fill info accourding to the file that we clicked
                ListBoxFill();
            }
        }

        private void PathBreakDown()
        {
            fileName = Path.GetFileNameWithoutExtension(path);
            string? directoryPath = Path.GetDirectoryName(path);
            if (directoryPath != null)
                if (fileName != null)
                    pathWithoutExtension = Path.Combine(directoryPath, fileName);
        }
        
        // this func is for fill the combo box in names of every file we loaded
        private void FillComboBox()
        {
            List<String> names = jsonHandler.ReadJsonNames();
            foreach (string name in names)
            {
                // comboBox is the comboBox in the mainWindow.xaml
                ComboBox.Items.Add(name);
            }
        }

        private void FillStudentDetail(Student? student)
        {
            StudentDetails.Items.Clear();
            for (int i = 0; i < coursesNames.Count; i++)
            {
                // Create the data model for each course
                if (student != null)
                {
                    var course = new CourseViewModel
                    {
                        CourseName = coursesNames[i],
                        Task = student.Tasks![i],
                        Percentage  = percentages[i]
                    };

                    // Create a custom ListBoxItem
                    ListBoxItem listBoxItem = new ListBoxItem();
                    // Create TextBox control for editing task grade
                    TextBox taskTextBox = new TextBox
                    {
                        Text = course.Task.ToString() // Set initial value
                    };
                    int i1 = i;
                    taskTextBox.TextChanged += (sender, e) =>
                    {
                        if (int.TryParse(taskTextBox.Text, out int taskValue))
                        {
                            if (taskValue is >= 0 and <= 100)
                            {
                                course.Task = taskValue;
                                student.Tasks[i1] = taskValue;
                            }
                            else
                            {
                                // If the entered value is not within the range, reset the text to the previous valid value
                                taskTextBox.Text = course.Task.ToString();
                                // Optionally, you can display a message to inform the user about the valid range.
                                MessageBox.Show("Task grade must be between 0 and 100.");
                            }
                        }
                        else
                        {
                            // If the entered text is not a valid integer, reset the text to the previous valid value
                            taskTextBox.Text = course.Task.ToString();
                            // Optionally, you can display a message to inform the user about the invalid input.
                            MessageBox.Show("Please enter a valid number.");
                        }
                    };


                    // Create TextBlock for displaying percentage
                    TextBlock percentTextBlock = new TextBlock
                    {
                        Text = course.Percentage  + "%"
                    };

                    // Add controls to the ListBoxItem
                    listBoxItem.Content = new StackPanel()
                    {
                        Orientation = Orientation.Horizontal,
                        Children =
                        {
                            new TextBlock { Text = course.CourseName },
                            new TextBlock { Text = " : " },
                            taskTextBox,
                            new TextBlock { Text = "  " }, // Add space between task grade and percentage
                            percentTextBlock // Display percentage as TextBlock
                        }
                    };

                    // Add the custom ListBoxItem to the ListBox
                    StudentDetails.Items.Add(listBoxItem);
                }
            }

            SaveButton.Tag = student;
            StudentDetails.Visibility = Visibility.Visible;
        }

        public class CourseViewModel
        {
            public string? CourseName { get; init; }
            public int Task { get; set; }
            public int Percentage  { get; init; }
        }
        // this func is for calculating the sum for every student based on grade and the percentage for every exam
        private float FinalGradeCalculator(Student student)
        {
            float sum = 0;
            for (int i = 0; i <student.Tasks!.Count; i++)
            {
                sum += (int)(student.Tasks[i] * ((double)percentages[i] / 100));
            }
            return sum;
        }

        private float AvgCalculator()
        {
            // this func is calculating the average for all students
            List<Student> students = jsonHandler.FindReadName(fileName)!;
            float sum=0; 
            foreach (Student s in students)
            {
                // this func is for sum all the points for every student
                sum += FinalGradeCalculator(s);
            }

            float avg =  sum / students.Count;
            return (float)Math.Round(avg, 2);
        }

        private void Grade()
        {
            if (fileName != null) CourseNameAvg.Text = fileName.PadRight(10) + ":".PadRight(10) + AvgCalculator();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            // to handle the save button event to save the edit has been done and to re-calculate the average
            Button button = (sender as Button)!;
            if (button.Tag is Student student)
            {
                jsonHandler.UpdateJson(fileName!,student);
                Grade();
            }
        }

    }
}

