﻿

namespace FinalProject
{
    // a data structure for storing the student details 
    public class Student(string? name, string? lastName, string? id, int year, List<int>? tasks)
    {
        public string? Name => name;
        public string? LastName => lastName;
        public string? Id => id;
        public int Year => year;
        public List<int>? Tasks => tasks;
    }
}
